#!/bin/bash

_yes=
read -p "确定要关闭 ssdb 吗? [Y/n]: " _yes
if [[ "$_yes" != "Y" ]]; then
	echo "已取消关闭 ssdb"
	exit 0
fi

echo ./bin/ssdb-server ssdb.conf -s stop
./bin/ssdb-server ssdb.conf -s stop
