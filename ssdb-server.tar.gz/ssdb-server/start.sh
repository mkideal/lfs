#!/bin/bash

if [[ $START_SSDB_NO_CONFIRM != 1 ]]; then
	_yes=
	read -p "确定要启动 ssdb 吗? [Y/n]: " _yes
	if [[ "$_yes" != "Y" ]]; then
		echo "已取消启动 ssdb"
		exit 0
	fi
fi

./bin/ssdb-server -d ssdb.conf -s restart
