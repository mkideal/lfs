This is a sample external plugin coded in C.
One of the advantages over an internal plugin is that a
developer does *not* need to know anything about rsyslog
internals in order to write a plugin. It's just a regular
C program.
