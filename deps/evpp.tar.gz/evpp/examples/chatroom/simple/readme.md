A simple chatroom

The original example code is at here [http://www.boost.org/doc/libs/1_35_0/doc/html/boost_asio/example/chat/chat_server.cpp](http://www.boost.org/doc/libs/1_35_0/doc/html/boost_asio/example/chat/chat_server.cpp).

And the implementation of [evpp]'s simple chatroom is modified from [muduo]'s examples [https://github.com/chenshuo/muduo/tree/master/examples/asio/chat](https://github.com/chenshuo/muduo/tree/master/examples/asio/chat).



[gtest]:https://github.com/google/googletest
[glog]:https://github.com/google/glog
[Golang]:https://golang.org
[muduo]:https://github.com/chenshuo/muduo
[libevent]:https://github.com/libevent/libevent
[libevent2]:https://github.com/libevent/libevent
[LevelDB]:https://github.com/google/leveldb
[rapidjson]:https://github.com/miloyip/
[Boost.Asio]:http://www.boost.org/
[boost.asio]:http://www.boost.org/
[asio]:http://www.boost.org/
[boost]:http://www.boost.org/
[evpp]:https://github.com/Qihoo360/evpp
[evmc]:https://github.com/Qihoo360/evpp/tree/master/apps/evmc
[evnsq]:https://github.com/Qihoo360/evpp/tree/master/apps/evnsq

