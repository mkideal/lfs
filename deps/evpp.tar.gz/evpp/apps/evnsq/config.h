#pragma once


#ifdef _WIN32
#include "evnsq/windows_port.h"
#else
#define EVNSQ_EXPORT
#endif